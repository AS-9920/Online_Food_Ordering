/*
 * package com.edubridge.entity;
 * 
 * import javax.persistence.Column; import javax.persistence.GeneratedValue;
 * import javax.persistence.GenerationType; import javax.persistence.Id;
 * 
 * public class User {
 * 
 * @Id
 * @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 * 
 * @Column(name="User_Name") 
 * private String name;
 * 
 * @Column(name="Email") 
 * private String Email;
 * 
 * @Column(name="Password") 
 * private String password;
 * 
 * 
 * public int getId() 
 * { 
 * 	return id; 
 * }
 * public void setId(int id) 
 * { 
 * 	this.id = id; 
 * }
 * 
 * public String getName() 
 * {
 *  return name; 
 * } 
 * public void setName(String name) 
 * {
 * 	this.name = name; 
 * }
 * 
 * public String getEmail() 
 * { 
 * 	return Email; 
 * } 
 * public void setEmail(String email)
 * { 
 * 	Email = email; 
 * }
 * 
 * public String getPassword() { return password; } public void
 * setPassword(String password) { this.password = password; }
 * 
 * @Override public String toString() { return "User [id=" + id + ", name=" +
 * name + ", Email=" + Email + ", password=" + password + "]"; }
 * 
 * }
 */