/*
 * package com.edubridge.entity;
 * 
 * import javax.persistence.Column; import javax.persistence.GeneratedValue;
 * import javax.persistence.GenerationType; import javax.persistence.Id;
 * 
 * public class Payments {
 * 
 * @Id
 * 
 * @GeneratedValue(strategy=GenerationType.IDENTITY) private int pId;
 * 
 * @Column(name="email") private String email;
 * 
 * @Column(name="bank") private String bank;
 * 
 * @Column(name="card") private int card;
 * 
 * @Column(name="ccv") private int ccv;
 * 
 * public int getpId() { return pId; } public void setpId(int pId) { this.pId =
 * pId; } public String getEmail() { return email; } public void setEmail(String
 * email) { this.email = email; } public String getBank() { return bank; }
 * public void setBank(String bank) { this.bank = bank; } public int getCard() {
 * return card; } public void setCard(int card) { this.card = card; } public int
 * getCcv() { return ccv; } public void setCcv(int ccv) { this.ccv = ccv; }
 * 
 * @Override public String toString() { return "Payments [pId=" + pId +
 * ", email=" + email + ", bank=" + bank + ", card=" + card + ", ccv=" + ccv +
 * "]"; } }
 */