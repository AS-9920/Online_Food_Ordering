/*
 * package com.edubridge.entity;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.GeneratedValue; import javax.persistence.GenerationType;
 * import javax.persistence.Id; import javax.persistence.Table;
 * 
 * @Entity
 * 
 * @Table(name="order_table") public class Order {
 * 
 * @Id
 * 
 * @GeneratedValue(strategy=GenerationType.IDENTITY) private int Oid;
 * 
 * @Column(name="Product_name") private String PName;
 * 
 * @Column(name="Email") private String Email;
 * 
 * @Column(name="Quantity") private int quantity;
 * 
 * @Column(name="Price") private double price;
 * 
 * public int getOid() { return Oid; }
 * 
 * public void setOid(int oid) { Oid = oid; }
 * 
 * public String getPName() { return PName; }
 * 
 * public void setPName(String pName) { PName = pName; }
 * 
 * public String getEmail() { return Email; }
 * 
 * public void setEmail(String email) { Email = email; }
 * 
 * public int getQuantity() { return quantity; }
 * 
 * public void setQuantity(int quantity) { this.quantity = quantity; }
 * 
 * public double getPrice() { return price; }
 * 
 * public void setPrice(double price) { this.price = price; }
 * 
 * @Override public String toString() { return "Order [Oid=" + Oid + ", PName="
 * + PName + ", Email=" + Email + ", quantity=" + quantity + ", price=" + price
 * + "]"; } }
 */