package com.edubridge.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ProductsTable")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pId;

	@Column(name = "Product_name")
	private String pName;

	@Column(name = "Price")
	private double price;

	public int getpId() {
	return pId;
	}
	public void setpId(int pId) {
	this.pId = pId;
	}
	public String getpName() {
	return pName;
	}
	public void setpName(String pName) {
	this.pName = pName;
	}
	public double getPrice() {
	return price;
	}
	public void setPrice(double price) {
	this.price = price;
	 }

	@Override
	public String toString() {
		return "Products [pId=" + pId + ", pName=" + pName + ", price=" + price + "]";
	}
}
