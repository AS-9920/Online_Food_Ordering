package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.edubridge.entity.Product;
import com.edubridge.repository.ProductsRepository;

@Service
public class ProductServiceImpl implements ProductService
{
	@Autowired
	private ProductsRepository productsRepository;
	@Override
	public Product saveProduct(Product product) 
	{
		return productsRepository.save(product);
	}
	
	@Override
	public List<Product> getAllProducts() 
	{
		// TODO Auto-generated method stub
		return productsRepository.findAll();
	}
}