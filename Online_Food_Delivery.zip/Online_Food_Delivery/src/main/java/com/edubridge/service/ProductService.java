package com.edubridge.service;

import java.util.List;
import com.edubridge.entity.Product;

public interface ProductService 
{
	public Product saveProduct(Product product);
	public List<Product> getAllProducts();
}